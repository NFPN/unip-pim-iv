# WEB
Parte de web e api para hotelaria

//Info para arrumar as refer�ncias do projeto
//https://stackoverflow.com/questions/32056665/how-can-i-fix-missing-nuget-references-after-moving-project-in-visual-studio-201
