﻿namespace BlackRiver
{
    public class BlackRiverConstants
    {
        public const string DatabaseName = "BlackRiverDB";

        public static string ConnectionString = @$"Data Source=DSK-PCSSD0001\SQLEXPRESS;Initial Catalog={DatabaseName};Integrated Security=True";
    }
}