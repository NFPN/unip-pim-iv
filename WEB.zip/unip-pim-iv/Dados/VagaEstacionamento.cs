﻿namespace BlackRiver.Data.Models
{
    public class VagaEstacionamento
    {
        public string NumeroVaga { get; set; }
        public string Placa { get; set; }
    }
}
