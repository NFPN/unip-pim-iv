﻿namespace BlackRiver.Data.Models
{
    public class Municipio
    {
        public string Nome { get; set; }
        public char[] UF { get; set; }
    }
}