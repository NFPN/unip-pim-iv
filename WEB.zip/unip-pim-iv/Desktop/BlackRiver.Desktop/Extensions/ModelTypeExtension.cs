﻿namespace BlackRiver.Desktop.Extensions
{
    public static class ModelTypeExtension
    {
    }
}
